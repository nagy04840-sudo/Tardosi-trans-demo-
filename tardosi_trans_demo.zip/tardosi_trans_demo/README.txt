TARDOSI TRANS – DEMÓ WEBOLDAL

Ez egy nem hivatalos, bemutató célú koncepció. Nem a Tardosi Trans megbízásából készült, és nem jelenti a cég jóváhagyását.

A csomag tartalma:
- index.html: teljes, reszponzív, magyar–angol statikus weboldal
- beépített CSS és JavaScript, külső függőség nélkül
- szolgáltatási mintakártyák, bemutatkozó rész, folyamat és kapcsolatfelvételi demóűrlap
- az űrlap a látogató levelezőprogramját nyitja meg; nincs szerveroldali adatküldés vagy adattárolás

Publikálás előtt:
1. A cég nevét, logóját, képeit, tényleges szolgáltatásait és elérhetőségeit csak írásos engedéllyel használd.
2. Minden mintaszöveget ellenőrizni és a cég által jóváhagyni kell.
3. Valódi érdeklődői adatgyűjtéshez biztonságos háttérrendszer és megfelelő adatkezelési tájékoztató szükséges.
4. Ne tüntesd fel hivatalos céges weboldalként a cég kifejezett jóváhagyása nélkül.

GitHub Pages:
A ZIP tartalmát külön GitHub repository-ba töltsd fel, és a Settings > Pages részen állítsd be a publikálást a main ág gyökérkönyvtárából. A meglévő Transport Digital CRM fájljait ne írd felül.
